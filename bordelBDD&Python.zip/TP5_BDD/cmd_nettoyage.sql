voir les tables en memoire

select * from tab;

select 'drop table ' || table_name || ' cascade constraints;' from user_tables;

purge recyclebin
