drop table Activite;
drop table Sejour;
drop table Client;
drop table Station;

create table Station
(nomStation VarChar2(20) primary key,
capacite Number(4),
lieu VarChar2(20),
region VarChar2(20),
tarif Number(5) DEFAULT 0);

create table Sejour
(
ID Number(4),
station VarChar2(20),
debut date,
nbPlaces Number(4)
);

create table Client
(
ID Number(4),
nom VarChar2(20),
prenom VarChar2(20),
ville VarChar2(20),
region VarChar2(20),
solde Number(5) DEFAULT 0
);

create table Activite
(
nomStation VarChar2(20),
libelle VarChar2(20),
prix Number(4) DEFAULT 0
);
