################################################
## Exercice de tri                           ##
################################################

def tribulle(liste):
    """
    tri une liste en suivant l'algorithme du tri a bulle
    parametre: liste, liste d'entier
    resultat: Attention cette fonction ne retourne aucun resultat mais modifie la liste
    N'oubliez le print(liste) a la fin de chaque iteration de la grande boucle
    """
    nb_element_tries = 0
    while nb_element_tries <= len(liste):
        for i in range(1,len(liste)-nb_element_tries):
            if liste[i-1] > liste[i]:
                tmp = liste[i-1]
                liste[i-1] = liste[i]
                liste[i] = tmp
        nb_element_tries += 1
        print(liste)

    
    

# A decommenter lorsque vous avez fini votre implementation      
l=[15,2,78,5,34,1]
tribulle(l)
assert l==[1,2,5,15,34,78],"Pb Appel tribulle("+str(l)+")"
# vos tests

l2 = [1,1,41,841,8,44,87,64,987,41,67,87,9884478,56,1548,74,4154,87,1,4,54,5,5418,56,87,564]
tribulle(l2)
assert l2 ==[1, 1, 1, 4, 5, 8, 41, 41, 44, 54, 56, 56, 64, 67, 74, 87, 87, 87, 87, 564, 841, 987, 1548, 4154, 5418, 9884478]
