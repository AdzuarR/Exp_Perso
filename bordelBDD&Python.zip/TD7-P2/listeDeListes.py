################################################
## Exercice sur les listes de listes          ##
################################################

# liste de listes pour le premier ascii art 
asciiart1=[[' ', '|', '\\', '/', '\\', '/', '\\', '/', '|', ' ', ' '],[' ', '|', ' ', ' ', ' ', ' ', ' ', ' ', '|', ' ', ' '],\
   [' ', '|', ' ', ' ', ' ', ' ', ' ', ' ', '|', ' ', ' '], [' ', '|', ' ', '(', 'o', ')', '(', 'o', ')', ' ', ' '],\
   [' ', 'C', ' ', ' ', ' ', ' ', ' ', ' ', '_', ')', ' '], [' ', ' ', '|', ' ', ',', '_', '_', '_', '|', ' ', ' '],\
   [' ', ' ', '|', ' ', ' ', ' ', '/', ' ', ' ', ' ', ' '], [' ', '/', '_', '_', '_', '_', '\\', ' ', ' ', ' ', ' '],\
   ['/', ' ', ' ', ' ', ' ', ' ', ' ', '\\']]

# liste de listes pour le deuxieme ascii art 
asciiart2=[[' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '_', 'n', 'n', 'n', 'n', '_'],\
    [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'd', 'G', 'G', 'G', 'G', 'M', 'M', 'b'],\
    [' ', ' ', ' ', ' ', ' ', ' ', ' ', '@', 'p', '~', 'q', 'p', '~', '~', 'q', 'M', 'b'],\
    [' ', ' ', ' ', ' ', ' ', ' ', ' ', 'M', '|', '@', '|', '|', '@', ')', ' ', 'M', '|'],\
    [' ', ' ', ' ', ' ', ' ', ' ', ' ', '@', ',', '-', '-', '-', '-', '.', 'J', 'M', '|'],\
    [' ', ' ', ' ', ' ', ' ', ' ', 'J', 'S', '^', '\\', '_', '_', '/', ' ', ' ', 'q', 'K', 'L'],\
    [' ', ' ', ' ', ' ', ' ', 'd', 'Z', 'P', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'q', 'K', 'R', 'b'],\
    [' ', ' ', ' ', ' ', 'd', 'Z', 'P', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'q', 'K', 'K', 'b'],\
    [' ', ' ', ' ', 'f', 'Z', 'P', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'S', 'M', 'M', 'b'],\
    [' ', ' ', ' ', 'H', 'Z', 'M', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'M', 'M', 'M', 'M'],\
    [' ', ' ', ' ', 'F', 'q', 'M', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'M', 'M', 'M', 'M'],\
    [' ', '_', '_', '|', ' ', '"', '.', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '|', '\\', 'd', 'S', '"', 'q', 'M', 'L'],\
    [' ', '|', ' ', ' ', ' ', ' ', '`', '.', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '|', ' ', '`', "'", ' ', '\\', 'Z', 'q'],\
    ['_', ')', ' ', ' ', ' ', ' ', ' ', ' ', '\\', '.', '_', '_', '_', '.', ',', '|', ' ', ' ', ' ', ' ', ' ', '.', "'"], \
    ['\\', '_', '_', '_', '_', ' ', ' ', ' ', ')', 'M', 'M', 'M', 'M', 'M', 'P', '|', ' ', ' ', ' ', '.', "'"],\
    [' ', ' ', ' ', ' ', ' ', '`', '-', "'", ' ', ' ', ' ', ' ', ' ', ' ', ' ', '`', '-', '-', "'", ' ', 'h', 'j', 'm']]


def liste_de_listes_to_str(liste):
    """
    cette fonction transforme une liste de listes en une chaine de caracteres
    ou les elements de la liste principale sont accoles sur une meme ligne
    parametre: liste, liste contenant des sous listes
    resultat: res, chaine de caractere concatenant les valeur presentent dans liste
    """
    
    res = ""
    for i in range(len(liste)):
        for elem in liste[i]:
            if elem != None:
                res += str(elem)
        res += '\n'
    return res
    
# A decommenter lorsque vous avez fini votre implementation
assert liste_de_listes_to_str([])=='',"Pb appel liste_de_listes_to_str([])"
assert liste_de_listes_to_str([[0,1,2],[3,4,5],[6,7,8]])=='012\n345\n678\n', "Pb appel liste_de_listes_to_str([[0,1,2][3,4,5][6,7,8]])"
assert liste_de_listes_to_str([['X',' ','O'],['O','X',' '],['O',' ','X']])=='X O\nOX \nO X\n',"Pb appel liste_de_listes_to_str([['X',' ','O'],['O','X',' '],['O',' ','X']])"
print(liste_de_listes_to_str(asciiart1))
print(liste_de_listes_to_str(asciiart2))
# vos tests

assert liste_de_listes_to_str([[],[],["b","o","b"],[],[]])=="\n\nbob\n\n\n"

def max_dans_liste_de_listes(liste):
    """
    retourne le plus grand element d'une liste de listes
    parametre: liste, liste contenant des sousliste d'entier naturel
    resultat: res, entier representant le plus grand entier present dans liste
    """
    res = None
    if liste != []:
        res = 0
        for i in range(len(liste)):

            for elem in liste[i]:
                if elem > res:
                    res = elem
    return res

# A decommenter lorsque vous avez fini votre implementation
assert max_dans_liste_de_listes([[0,1,2],[3,4,5],[6,7,8]])==8,"Pb appel max_dans_liste_de_listes([[0,1,2],[3,4,5],[6,7,8]])"
assert max_dans_liste_de_listes([[0,11,25],[7,14,58],[26,17,8]])==58,"Pb appel max_dans_liste_de_listes([[0,11,25],[7,14,58],[26,17,8]])"
assert max_dans_liste_de_listes([])==None,"Pb appel max_dans_liste_de_listes([])"
# vos tests

#assert max_dans_liste_de_listes([[]])==None
assert max_dans_liste_de_listes([[],[1,2,3]])==3
#assert max_dans_liste_de_listes([[],[None,1,2,3]])==3 # A debugger!!!

def max_par_ligne_dans_liste_de_listes(liste):
    """
    retourne la liste des plus grands elements de chaque ligne dans une liste de listes
    parametre: liste, liste contenant des sousliste d'entiers
    resultat: res, liste contenant l'entier maximale de chaque sousliste a indice identique
    """
    
    res = []
    for i in range(len(liste)):
        if liste[i] != []:
            maxi = liste[i][0]
            for elem in liste[i]:
                if maxi < elem:
                    maxi = elem
            res.append(maxi)
        else:
            res.append(None)
    return res
    
# A decommenter lorsque vous avez fini votre implementation
assert max_par_ligne_dans_liste_de_listes([[0,1,2],[3,4,5],[6,7,8]])==[2,5,8],\
       "Pb Appel max_par_ligne_dans_liste_de_listes([[0,1,2],[3,4,5],[6,7,8]])"
assert max_par_ligne_dans_liste_de_listes([[0,11,25],[7,14,58],[26,17,8]])==[25,58,26],\
       "Pb Appel max_par_ligne_dans_liste_de_listes([[0,11,25],[7,14,58],[26,17,8]])"
assert max_par_ligne_dans_liste_de_listes([[45,1,24],[],[47,85,2,14]])==[45,None,85],\
       "Pb Appel max_par_ligne_dans_liste_de_listes([[45,1,24],[],[47,85,2,14]])"
# vos tests

assert max_par_ligne_dans_liste_de_listes([[],[],[1,2,3]])==[None,None,3]
