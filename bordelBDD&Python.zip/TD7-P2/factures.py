################################################
## Exercice sur les facture                   ##
################################################

def factures(liste_commandes):
    '''
    paramètre:
    resultat:
    '''
    pass

#assert(factures([(123,"Dupont",[("Verre",6,2.4),("Assiette",6,1.5)]),(125,"Durand",[("vase",1,10.0)])])==[(123, 'Dupont', 23.4), (125, 'Durand', 10.0)])
# vos tests

def affiche_factures(liste_commandes):
    '''
    paramètre:
    resultat:
    '''
    pass

# affiche_factures([(123,"Dupont",[("Verre",6,2.4),("Assiette",6,1.5)]),(125,"Durand",[("vase",1,10.0)])])
