def boucles_imbliquees (N ,M ):
    nombre_fois_instruction_jouee = 0
    for i in range (N):
        print (" - j ' effectue le tour " ,i , " de la boucle externe ")
        for j in range (M):
            print (" ++ j ' effectue le tour " ,j ," de la boucle interne " )
            nombre_fois_instruction_jouee += 1
    print (nombre_fois_instruction_jouee)
    
boucles_imbliquees(5,2)
